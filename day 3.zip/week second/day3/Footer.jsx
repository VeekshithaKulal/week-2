import React,{ Component} from "react";
class Footer extends Component{
    render(){
        return(
            <>
                <hr/>
                <h3> Contact</h3>
                <p>
                    <b>Mobile : </b>9876543210
                </p>
                <p>
                    <b>Email :</b>my@gmail.com
                </p>
            </>
        );

    }
}
export default Footer;