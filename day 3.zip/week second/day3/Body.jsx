import React from "react"
const Body =() =>{
    return(
    <>
        <hr/>
        <h3>About me</h3>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit.
             Fuga et dolorum cumque fugiat doloribus commodi ea ipsam illum pariatur quod amet quos assumenda voluptate sit, 
             quibusdam cum suscipit corporis quo.
        </p>

    </>
    );
};
export default Body;