import React  from  'react'
import './Header.css'

function Header(){
    return (
        <div id='box'>
            <h1>Mahatma Gandhi</h1>
            <img id="imgg"src="https://th.bing.com/th/id/OIP.c_7kUZjPuu5J1F_AzA2p4QAAAA?pid=ImgDet&rs=1" width={250}
            alt="Loading......." />

        </div>
        
        
    )

}

export default Header