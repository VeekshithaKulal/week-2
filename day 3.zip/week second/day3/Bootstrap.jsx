import React from "react";
import "bootstrap/dist/css/bootstrap.min.css"

function Bootstrap(){
    return (
        <>
        <h1 className="text-primary text-center">Bootstrap</h1>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Earum minus ratione amet consequuntur? Ipsa, neque nostrum deserunt sint tempora illo, fugiat unde sed sapiente, libero numquam exercitationem natus itaque quo?</p>
        </>
    )
}

export default Bootstrap;