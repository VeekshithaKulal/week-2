import React from "react"
// import "bootstrap/dist/css/bootstrap.min.css";

function Signup(){
    return(
        <>
            <h1>Signup Page</h1>
        </>
    )
    
} 
export default Signup;