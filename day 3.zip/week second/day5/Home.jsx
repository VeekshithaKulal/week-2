import React from 'react';

function Home(){
    return(
        <>
            <h1>Hello there</h1>
        </>
    )
}

export default Home;